<?php
   $database = "bulgaria";
   $user = "web_user";
   $password  = "Password1";
   $host = "db";
?>
